﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ToetsBramFrieling
{
    public static class MyFunctions
    {
        public static List<int> CreateNumberSequence(int jaar)
        {
            //controlleer of het een geldige input is
            if (jaar < 1 && jaar > 3000)
            {
                throw new ArgumentException("Ongeldige invoer");
            }

            //maak een lege list aan waar de resultaten in komen te staan
            List<int> results = new List<int>();

            //een for loop om door alle jaren te gaan tot en met het jaar van nu
            for (int i = jaar; i <= 2024; i++)
            {
                //de bereking voor een schrikkeljaar en voeg die daarna toe aan results 
                if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))
                {
                    results.Add(i);
                }
            }

            return results;
        }


        public static string CaesarEncrypt(string naam, int code)
        {
            //controleer of de input geldig is
            if (code < 1 && code > 10)
            {
                throw new ArgumentException("Ongeldige invoer");
            }

            //kijk of de naam niet niets kan zijn
            if (naam == null)
            {
                throw new ArgumentNullException(nameof(naam), "Invoer kan niet null zijn.");
            }

            //de naam los in een chararray zetten
            char[] charLetter = naam.ToCharArray();
            //met een for loop door elke letter heen gaan
            for (int i = 0; i < charLetter.Length; i++)
            {
                char Losletter = charLetter[i];

                if (char.IsLetter(Losletter))
                {
                    char offset = char.IsUpper(Losletter) ? 'A' : 'a';
                    Losletter = (char)((Losletter + code - offset) % 26 + offset);
                }

                charLetter[i] = Losletter;
            }
            return new string(charLetter);
        }

    }
}

