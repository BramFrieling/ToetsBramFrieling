﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ToetsBramFrieling.Controllers
{
    public class Opdracht2Controller : Controller
    {
        public IActionResult Opdracht2(string naam, int code)
        {
            //controleer of de input geldig is
            if (code < 1 && code > 10)
            {
                ViewData["restult"] = "Ongeldige invoer";
            }

            string test = "";
            //zorg dat de naam niet leeg mag zijn 
            if (naam != null )
            {
                test = MyFunctions.CaesarEncrypt(naam, code);
            }

            //geef alles terug
            ViewData["naam"] = naam;
            ViewData["restult"] = test;

            return View();
        }
    }
}

