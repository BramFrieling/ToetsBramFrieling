﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ToetsBramFrieling.Controllers
{
    public class Opdracht1Controller : Controller
    {
        public IActionResult Opdracht1()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Schrikkeljaar(int jaar)
        {
            //controleer of het een geldige invoer is
            if (jaar < 1 && jaar > 3000)
            {
                ViewData["Error"] = "Ongeldige invoer";
            }

            //roep de functie aan die staat als een statische methode in de class MyFunctions
            var schrikkeljaar = MyFunctions.CreateNumberSequence(jaar);

            //geef eerst het jaar terug van de input
            ViewData["schrikkeljaar"] = jaar;
            //geef de lijst terug naar de view
            ViewData["Jaargetallen"] = schrikkeljaar;

            return View("Opdracht1");
        }
    }
}

