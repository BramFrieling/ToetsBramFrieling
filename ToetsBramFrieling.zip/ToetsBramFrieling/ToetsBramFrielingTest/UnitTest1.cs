﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ToetsBramFrielingTest;

[TestClass]
public class UnitTest1
{
    [TestMethod]
    public void CreateNumberSequenceTest()
    {
        // Arrange
        int inputYear = 2018; // Change this to any year you want to test
        List<int> expectedLeapYears = new List<int> { 2020, 2024 };

        // Act
        List<int> actualLeapYears = MyFunctions.CreateNumberSequence(inputYear);

        // Assert
        CollectionAssert.AreEqual(expectedLeapYears, actualLeapYears);
    }
}
